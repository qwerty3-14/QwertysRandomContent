using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace QwertysRandomContent.Items.Weapons.Rhuthinium
{
	public class RhuthiniumArrow : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Rhuthinium Arrow");
			Tooltip.SetDefault("Does more damage the longer it's in flight");
			
		}
		public override void SetDefaults()
		{
			item.shootSpeed = 3f;
				item.shoot = mod.ProjectileType("RhuthiniumArrowP");
				item.damage = 5;
				item.width = 14;
				item.height = 32;
				item.maxStack = 999;
				item.consumable = true;
				item.ammo = AmmoID.Arrow;
				item.knockBack = 2f;
            item.rare = 3;
				item.value = 5;
				item.ranged = true;
			
			
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.ItemType("RhuthiniumBar"), 1);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this, 100);
			recipe.AddRecipe();
		}
	}
	public class RhuthiniumArrowP : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Rhuthinium Arrow");
			
			
		}
		public override void SetDefaults()
		{
			projectile.aiStyle = 1;
			projectile.width = 10;
			projectile.height = 10;
			projectile.friendly = true;
			projectile.penetrate = 1;
			projectile.ranged= true;
			projectile.arrow=true;
			
			projectile.tileCollide = true;
			
			
		}
        public int timer;
        public bool runOnce = true;
        public float oriDamage;
        public override void AI()
        {
            if(runOnce)
            {
                oriDamage = projectile.damage;
                runOnce = false;
            }
            timer++;
            if(timer>300)
            {
                timer = 300;
            }
            projectile.damage = (int)(oriDamage * (((float)timer / 30f)));


        }





    }
	
}

